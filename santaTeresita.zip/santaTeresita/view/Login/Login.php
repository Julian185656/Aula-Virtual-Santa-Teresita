<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="../Styles/Login.css">
</head>
<body>
<div class="form">
    <h1>Registrar Usuario</h1>

    <?php
    session_start();
    if (isset($_SESSION['success_message'])) {
        echo "<p style='color:green'>" . $_SESSION['success_message'] . "</p>";
        unset($_SESSION['success_message']);
    }
    if (isset($_SESSION['error_message'])) {
        echo "<p style='color:red'>" . $_SESSION['error_message'] . "</p>";
        unset($_SESSION['error_message']);
    }
    ?>

    <form method="POST" action="../../controller/LoginController.php">
        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" id="nombre" name="nombre" required>
        </div>
     
        <div class="form-group">
            <label for="correo">Correo</label>
            <input type="email" id="correo" name="correo" required>
        </div>
        <div class="form-group">
            <label for="telefono">Teléfono</label>
            <input type="text" id="telefono" name="telefono">
        </div>
        <div class="form-group">
            <label for="contra">Contraseña</label>
            <input type="password" id="contra" name="contra" required>
        </div>
        <div class="form-group">
            <label for="rol">Rol</label>
            <select id="rol" name="rol" required>
                <option value="Estudiante">Estudiante</option>
                <option value="Docente">Docente</option>
                <option value="Padre">Padre</option>
                <option value="Administrador">Administrador</option>
            </select>
        </div>
        <div class="form-group">
            <button type="submit" name="btn-registrarse">Registrarse</button>
        </div>
    </form>
</div>
</body>
</html>
