<?php
    header('location: view/Login/login.php');      
?>